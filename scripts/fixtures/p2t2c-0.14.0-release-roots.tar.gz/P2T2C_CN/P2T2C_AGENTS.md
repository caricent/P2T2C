# P2T2C_AGENTS.md — P2T2C AI 操作入口

这是本发行根唯一的 P2T2C AI 操作入口。

P2T2C 表示 **Proposal-to-Truth-to-Code**。默认行为是持续推进；只有尚未决定的 R2 语义、接受漂移实现并改 Truth、危险操作、外部权限、重复失败或无法安全集成时暂停。

五个治理状态在运行时合并为三个连续循环：

```text
准入 + 路由 -> 计划 + 执行 -> 验证 + 修复 + 漂移 + 收口
```

## 1. 基础读取

开始任务时读取：

1. `P2T2C_AGENTS.md`
2. `.p2t2c/project_config.yaml`；缺失时读取示例
3. `docs/sot/manifest.yaml`
4. 与当前意图直接相关的 SoT、ADR、代码和测试

默认不读 `docs/reference/**` 和治理历史。只有历史审计、迁移或冲突排查时读取。CPK、work、运行 ledger 和聊天都不能覆盖 Truth。

## 2. 双轴路由

先判断风险，再判断 execution shape；发现新影响时只能向上升级。

- `R0`：不改变 Truth；重构、测试、文档、CI、只读探索或恢复既有行为。
- `R1`：实现当前 Truth 已定义行为；不得修改 Truth。
- `R2`：改变 Truth、ADR、外部契约、持久数据、安全、隐私、权限或不可逆边界。

execution shape：

- `spike`：有界且可丢弃，不交付生产/Truth 变更；需要交付时升级。
- `bounded`：影响清晰，可由一个工作批次整体验收。
- `architectural`：跨边界，需要任务 DAG、文件所有权或分阶段集成。

持久产物：

| 场景 | 产物 |
|---|---|
| R0 | 默认无文档；审计模式或剩余风险策略要求时自动极简 CR |
| bounded R1 | 单一 CPK v3，closure evidence 投射在内 |
| architectural R1 | CPK v3 + `work.md`，证据投射进 CPK |
| bounded R2 | 完整 CPK v3 + Truth Patch + 自动 CR |
| architectural R2 | 完整 CPK v3 + Truth Patch + `work.md` + 自动 CR |

`SP-*` 可选。新 bounded 工作拒绝 spec/plan/tasks；只有 architectural CPK 声明 `legacy_startup_evidence: true` 时保留真实旧流程启动三件套。

CPK v3 还声明 Truth Patch ref+digest、唯一 ownership batch IDs、legacy startup。R2 digest 匹配单一 SoT 文件；bounded/spike ownership=none。spike 不得 applied/close。

## 3. 三个运行循环与 Prompt

五个 Prompt 是治理状态检查表，不是五次必须交接：

| 运行循环 | Prompt | 结果 |
|---|---|---|
| 准入 + 路由 | `01_intent_admission_prompt.md` + `02_risk_routing_and_truth_prompt.md` | 清晰意图、风险、shape、CPK/Gate A（如需） |
| 计划 + 执行 | `03_execute_work_batch_prompt.md` | CPK 内策略或 architectural work、实现与 ledger |
| 验证 + 修复 + 漂移 + 收口 | `04_verify_and_repair_prompt.md` + `05_drift_and_closure_prompt.md` | final-tree 证据、审查、漂移处理、CPK/CR receipt |

同一 controller 默认连续推进。上下文压缩或交接后，从 CPK/work、文件式 brief/diff/evidence、Git 和当前 run ledger 恢复。

## 4. 机器证据与验证 profile

ledger 记录 quiet command events（含 pending Gate A 的 safe exploration）、route/isolation/repair/Gate B 与 batch/global/specialist/re_review。事件绑定 tree SHA 与 contract digest。

- 手写 `Pass`、RED 或审查声明不是执行证据。
- receipt 的 `evidence_trust: local_consistency` 只保证当前本地仓库的非对抗一致性，不是签名或远程证明。
- 每个 changed path 必须命中 `verification.path_mapping`；缺映射/command ID/config digest 是核心硬失败，不允许 fallback。
- R2 或 multi-Agent work 的 primary verification 必须在最终 tree 上运行 full；`governance_change: true` 还必须在同一 final tree 上完成完整 governance 命令集。
- close 原子投射 receipt、运行普通 checker、再清理 run；失败恢复目标并保留 state。receipt 投射 Truth/ownership/legacy、mapping、baseline、advisory completeness/warnings 与 remaining-risk ref。

## 5. Agent 自治边界

Agent 可以自主完成 Truth/ADR 检索、影响面与路由初判、CPK 填充、任务 DAG、文件所有权、验证选择、基线管理、根因调查、Execution Doc Drift 回填和证据投射。

- read-only 探索可全面并行；写并行只允许所有权不重叠、隔离基线明确且有单一集成 controller。
- 只有 controller 可以派生 Agent；implementer/reviewer 不递归 fan-out。
- 同形微任务合并一次 dispatch 与一次批次审查；reviewer 逐项核对 brief。
- 子 Agent 显式选择快速/标准/最强模型与推理档；采用事件式有界等待。
- R2、并行或明确要求时使用 workspace isolation；不得强删含未跟踪/未提交内容的 worktree。

按需读取 `.p2t2c/skills/`：设计澄清、风险感知 TDD、根因调试、独立审查和工作区隔离。方法不能定义业务行为或绕过关卡。

## 6. 审查、修复与人类关卡

- bounded R1 生产代码：一次独立综合审查。
- architectural R1 / 所有 R2：ownership batch 审查 + final-tree 全局审查；安全、权限、迁移 R2 增加专项审查。
- architectural 每个 ownership ID 必须 batch review，再做 global/适用 specialist；修复用 re_review 回链原 scope。reviewer 与 implementer 不同，所有 finding 为 0。
- 两轮修复都恢复原 implementer，复审只覆盖 finding + fix diff；第三轮停线。

Gate A 只决定尚未明确的 R2 语义。当前指令已给出完整决定时记录 `gate_a: satisfied`，不重复确认。

实现明确违反 Truth 时先自动修正并重验，不触发 Gate B。只有接受该实现并修改 Truth 时才记录 `gate_b` 事件，把 status 置为 resolved，并用 decision/ref/truth_patch_ref 回链人类决定与 Truth Patch；危险、不可逆或外部副作用操作始终需要人类授权。

## 7. 收口规则

- R1 将 closure evidence 自动投射到 CPK。
- R2 自动生成与 CPK 同名映射的 CR。
- R0 默认无收口文档；审计模式或剩余风险策略要求时自动极简 CR。
- R0 条件性收口必须传 `--verification-profile`、`--remaining-risk-status` 和 `--remaining-risk-ref`；recorded 需要非 none ref，none 需要 ref=none。spike 永不 close。
- 没有适用的 final-tree 新鲜验证、必需审查或 evidence receipt，不得声明 `CLOSE`。

## 8. 安装与升级安全

安装升级保留项目资产。v0.14 advisory 仍硬门控核心证据；方法缺口进入 `evidence_warnings` 并使 `evidence_completeness` 不完整，不能冒充 complete。真实 A/B 与人类决定后才推广 required。

应用前先 dry-run：

```bash
make p2t2c-install-dry-run TARGET=/path/to/project
cd /path/to/project
/path/to/P2T2C_CN/.p2t2c/bin/p2t2c_upgrade.sh --dry-run --source /path/to/P2T2C_CN
```
