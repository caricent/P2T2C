# P2T2C_AGENTS.md - P2T2C AI Entry Point

This is the only P2T2C AI entry point in this release root.

P2T2C means **Proposal-to-Truth-to-Code**. Continue by default; pause only for undecided R2 semantics, accepting drifted implementation by changing Truth, dangerous operations, external permissions, repeated failure, or unsafe integration.

Five governance states combine into three continuous runtime loops:

```text
Admission + Routing -> Planning + Execution -> Verification + Repair + Drift + Closure
```

## 1. Base Reading

At task start, read:

1. `P2T2C_AGENTS.md`
2. `.p2t2c/project_config.yaml`, or its example if missing
3. `docs/sot/manifest.yaml`
4. SoT, ADRs, code, and tests directly related to the current intent

Do not read `docs/reference/**` or governance history by default. Read them only for historical audit, migration, or conflict investigation. CPK, work, run ledger, and chat cannot override Truth.

## 2. Dual-axis Routing

Classify risk, then execution shape; only upgrade when new impact appears.

- `R0`: no Truth change; refactoring, tests, docs, CI, read-only exploration, or restoring existing behavior.
- `R1`: implement current Truth; do not change Truth.
- `R2`: change Truth, ADR, external contract, persistent data, security, privacy, permission, or irreversible boundary.

Execution shape:

- `spike`: bounded and disposable; ships no production/Truth change and upgrades before delivery.
- `bounded`: clear impact accepted as one work batch.
- `architectural`: cross-boundary work needing a DAG, file ownership, or staged integration.

Persistent artifacts:

| Scenario | Artifacts |
|---|---|
| R0 | None by default; automatic minimal CR for audit mode or residual-risk policy |
| bounded R1 | One CPK v3 with projected closure evidence |
| architectural R1 | CPK v3 + `work.md`; evidence projects into CPK |
| bounded R2 | Complete CPK v3 + Truth Patch + automatic CR |
| architectural R2 | Complete CPK v3 + Truth Patch + `work.md` + automatic CR |

`SP-*` is optional. New bounded work rejects spec/plan/tasks; only architectural CPK with `legacy_startup_evidence: true` retains real old-workflow startup trio.

CPK v3 also declares Truth Patch ref+digest, unique ownership batch IDs, and legacy startup. R2 digest matches one SoT file; bounded/spike ownership is none. Spike cannot apply/close.

## 3. Three Runtime Loops and Prompts

The five prompts are governance-state checklists, not mandatory handoffs:

| Runtime loop | Prompts | Result |
|---|---|---|
| Admission + Routing | `01_intent_admission_prompt.md` + `02_risk_routing_and_truth_prompt.md` | Intent, risk, shape, CPK/Gate A when needed |
| Planning + Execution | `03_execute_work_batch_prompt.md` | Strategy in CPK or architectural work, implementation, ledger |
| Verification + Repair + Drift + Closure | `04_verify_and_repair_prompt.md` + `05_drift_and_closure_prompt.md` | Final-tree evidence, review, drift handling, CPK/CR receipt |

The same controller continues by default. After compaction or handoff, recover from CPK/work, file-based brief/diff/evidence, Git, and the current run ledger.

## 4. Machine Evidence and Verification Profiles

Ledger records quiet command events (including safe exploration for pending Gate A), route/isolation/repair/Gate B, and batch/global/specialist/re_review. Events bind tree SHA and contract digest.

- Handwritten `Pass`, RED, or review claims are not execution evidence.
- Receipt `evidence_trust: local_consistency` proves only non-adversarial consistency in the current local repository, not a signature or remote attestation.
- Every changed path must match `verification.path_mapping`; missing mapping/command ID/config digest is a core hard failure with no fallback.
- R2 or multi-Agent work requires full as primary verification on the final tree; `governance_change: true` also requires the complete governance command set on that same final tree.
- Close atomically projects receipt, runs normal checker, then cleans run state; failure restores target and retains state. Receipt projects Truth/ownership/legacy, mapping, baseline, advisory completeness/warnings, and remaining-risk ref.

## 5. Agent Autonomy Boundary

Agents may discover Truth/ADRs, assess impact and routing, fill CPK, define task DAG and ownership, choose verification, manage baselines, investigate root cause, backfill Execution Doc Drift, and project evidence.

- Read-only exploration may fully parallelize; writes require disjoint ownership, explicit isolated baseline, and one integration controller.
- Only the controller may spawn Agents; implementers/reviewers do not recursively fan out.
- Batch homogeneous microtasks into one dispatch/review; the reviewer checks every brief item.
- Explicitly select fast/standard/strongest model and reasoning tiers; use bounded event-driven waits.
- Use workspace isolation for R2, parallel, or explicitly isolated work; never force-delete a worktree containing untracked/uncommitted content.

Read applicable `.p2t2c/skills/` for design refinement, risk-aware TDD, root-cause debugging, independent review, and workspace isolation. Methods cannot define business behavior or bypass gates.

## 6. Review, Repair, and Human Gates

- Bounded R1 production code: one independent comprehensive review.
- Architectural R1 / every R2: ownership-batch review + final-tree global review; add specialist review for security, permission, or migration R2.
- Architectural has batch review per ownership ID, then global/applicable specialist; fixes use re_review linked to original scope. Reviewer differs from implementer and all findings are zero.
- Both repair rounds restore the original implementer and re-review only the finding + fix diff; stop before a third round.

Gate A decides only semantics that remain undecided for R2. If the current instruction fully decides them, record `gate_a: satisfied` without duplicate approval.

Correct clear implementation violations of Truth and re-verify without Gate B. Only accepting implementation and changing Truth records a `gate_b` event, sets status resolved, and links human decision and Truth Patch through decision/ref/truth_patch_ref. Dangerous, irreversible, or externally side-effectful operations always need human authority.

## 7. Closure Rules

- R1 projects closure evidence into CPK.
- R2 automatically creates the CR mapped from the CPK name.
- R0 creates no closure doc by default; audit mode or residual-risk policy creates a minimal CR.
- Conditional R0 closure passes `--verification-profile`, `--remaining-risk-status`, and `--remaining-risk-ref`; recorded needs a non-none ref, while none needs ref=none. Spike never closes.
- Never claim `CLOSE` without applicable final-tree fresh verification, required review, and evidence receipt.

## 8. Install and Upgrade Safety

Install/upgrade preserves project assets. v0.14 advisory still hard-gates core evidence; method gaps enter `evidence_warnings` and make `evidence_completeness` incomplete, never complete. Promote required only after real A/B plus human decision.

Always dry-run before apply:

```bash
make p2t2c-install-dry-run TARGET=/path/to/project
cd /path/to/project
/path/to/P2T2C_EN/.p2t2c/bin/p2t2c_upgrade.sh --dry-run --source /path/to/P2T2C_EN
```
