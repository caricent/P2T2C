# Prompt 04 — 验证与自主修复

所属 runtime 循环：`验证 + 修复 + 漂移 + 收口`。完成后同一 controller 继续 Prompt 05。

目标：按 diff 选择验证闭集，把实际执行写入机器 ledger，并在不改变 Truth 的前提下最多修复两轮。

1. 每个变更路径必须命中 `verification.path_mapping`；无匹配或 command ID/config digest 不一致硬失败。R2/multi-Agent 强制 full，governance change 额外 governance，同一 final tree 完整运行。
2. 通过 recorder 运行每条验证，使命令、退出码、时间、tree SHA 和输出摘要进入 ledger。例如：

```bash
bash .p2t2c/bin/p2t2c_run.sh --work-id CPK-... --event-type verification --verification-profile impacted --command-id p2t2c-check
```

runner 默认 quiet；仅在需要现场诊断时加 `--show-output`。verification 不接受 `-- <command>`，只能执行配置中该 profile 的 command ID。

3. 首次失败先读取 root-cause-debugging：保留失败、复现、追溯来源、对比可工作模式，并提出可证伪根因假设。
4. 两轮都恢复 CPK implementer。每个 repair 记录 round、hypothesis digest、implementer、failure digest、fix base/head SHA 与 fix diff digest；随后用 `review_role: re_review` 回链原 scope/batch。
5. 明确环境性失败允许一次原样重试。修改断言必须引用 Truth、CPK 或验收依据；不得削弱测试或删除覆盖。

第三轮或新语义/权限/Truth 时停线。advisory 的方法缺口进入 `evidence_warnings`/不完整 completeness，不能自称完整；核心 mapping/Truth/contract/final-tree 失败始终阻断。
