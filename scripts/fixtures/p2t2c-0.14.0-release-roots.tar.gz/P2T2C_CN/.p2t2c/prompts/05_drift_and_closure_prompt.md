# Prompt 05 — 漂移、审查与收口

所属 runtime 循环：`验证 + 修复 + 漂移 + 收口`。目标是在最终 tree 上完成漂移判断、适应性审查与机器证据投射。

1. 对比最终代码、Truth/ADR、CPK 和 work。Execution Doc Drift 自动回填 CPK/work。
2. 实现明确违反 Truth 时，恢复 CPK `implementer` 修正并重新验证，不触发 Gate B。只有接受实现并修改 Truth 才记录 `gate_b` 事件，把 `gate_b_status` 置为 resolved，并填写非空 decision/ref 与实际 `truth_patch_ref`。
3. bounded 用 batch_id=none；architectural 的每个 CPK ownership ID 都有 batch review，再做 global；按标志做 specialist。修复复审用 re_review 回链原 batch/scope。
4. 任一必需 review 的 Critical、Important 或 Minor 非零都阻断 CLOSE。由原 implementer 修复后只 scoped re-review finding 与 fix diff，并确保 final-tree 验证仍新鲜。
5. 使用 close 工具校验 ledger 并投射 receipt：

```bash
bash .p2t2c/bin/p2t2c_close.sh --work-id CPK-... --verification-profile full
```

6. receipt 投射 Gate A/Truth/ownership/legacy、`methodology_enforcement`、`evidence_completeness`、`evidence_warnings`、mapping/matched paths、baseline/risk ref。warning 不得冒充 complete；close 失败回滚。

没有 final-tree 必需验证/审查、存在阻断 finding、或 evidence digest 不匹配时不得声明 `CLOSE`。
