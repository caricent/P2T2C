# Prompt 03 - Plan and Execute a Work Batch

Runtime loop: `Planning + Execution`. The same controller normally continues from routing.

Prerequisites: risk/shape is known; R1/R2 has valid CPK v3; R2 `gate_a` is not pending.

Document intensity:

- R0/spike creates no execution doc.
- Bounded R1/R2 keeps strategy, acceptance, and ownership in CPK without the legacy trio.
- Architectural R1/R2 uses one `work.md` for interfaces/data flow, task DAG, file ownership, integration order, verification, and recovery points.

Execution discipline:

1. Create a work-id-isolated ledger; every event carries current contract digest. Gate A pending runs only `exploration` command events. Runner is quiet by default; use `--show-output` explicitly.
2. `tdd_policy: required` uses RED/GREEN; a compliant exemption uses `tdd_policy: exempt` plus a `tdd_exemption` event; use `not_applicable` only when truly inapplicable. Prompt/skill/script work prefers consumer behavior tests and mutation checks when applicable.
3. Architectural parallel writes use unique CPK ownership batch IDs, each with independent review. Bounded creates no legacy trio; only architectural legacy=true retains startup trio.
4. Only the controller spawns Agents; implementers/reviewers do not fan out. Explicitly select fast/standard/strongest model and reasoning tiers, and use bounded event-driven waits.
5. Use workspace isolation for R2, parallel, or explicitly isolated work; preserve user changes and never force-delete a nonempty worktree.
6. Continuously check CPK/work/Truth. Return to Prompt 01/02 for new semantics or upgrade conditions instead of silently expanding scope.

On completion, report diff, ledger, TDD, baseline, ownership, full/governance, and batch/global/specialist/re_review; do not create a chat log.
