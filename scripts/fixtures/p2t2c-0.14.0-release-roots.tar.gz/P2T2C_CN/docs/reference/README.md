# 历史参考

这里放历史资料、导出文档、截图、旧版规格、供应商文档等非权威参考资料。

`SUPERPOWERS_ATTRIBUTION.md` 记录 0.13.0 原生方法层的方法来源说明；它不是业务 Truth，也不引入上游插件依赖。

Reference 文档不是默认实现依据。如果 reference 内容要改变当前项目 Truth，必须先创建 SP 并更新 SoT。
