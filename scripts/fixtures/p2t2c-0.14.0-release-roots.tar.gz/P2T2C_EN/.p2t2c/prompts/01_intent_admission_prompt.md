# Prompt 01 - Intent Admission

Runtime loop: `Admission + Routing`. Continue directly to Prompt 02 with the same controller; no handoff is required.

Goal: Confirm that intent is observable, conflict-free against current Truth, and reduced to the minimum context for a later file-based brief.

Read the P2T2C entry, project config, Truth manifest, and directly related SoT, ADRs, code, and tests. Do not read reference/history by default or create an SP merely to enter the workflow.

Actions:

1. State goal, non-goals, observable acceptance, and explicit authority boundary.
2. Discover relevant Truth/ADRs and implementation, distinguishing decided facts, implementation defects, and genuinely undecided questions.
3. Mark boundaries that may affect risk, execution shape, data/security/permission, or dangerous operations.
4. Use design-refinement only for an ambiguity that changes outcomes; present options and a recommendation. The decision stays in current instruction, optional SP, or R2 CPK, not parallel Truth.
5. Continue immediately to Prompt 02 when conflict-free.

Pause only for a material ambiguity, Truth/ADR conflict, invented new semantics, dangerous operation, or external permission. Output the admission result, evidence paths, and compact intent brief.
