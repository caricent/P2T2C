# Prompt 01 — 意图准入

所属 runtime 循环：`准入 + 路由`。完成后由同一 controller 直接继续 Prompt 02，不要求交接。

目标：确认意图可验收、与当前 Truth 无冲突，并提取后续文件式 brief 所需的最小上下文。

先读取 P2T2C 入口、项目配置、Truth manifest，以及直接相关的 SoT、ADR、代码和测试。默认不读 reference/history，不为进入流程强制创建 SP。

动作：

1. 写出目标、非目标、可观察验收结果和明确授权边界。
2. 检索相关 Truth/ADR 与当前实现，区分已有决定、实现缺陷和真正未决定的问题。
3. 标记可能影响风险、execution shape、数据/安全/权限或危险操作的边界。
4. 仅对会改变结果的歧义使用 design-refinement；提供选项与推荐，人类决定仍进入当前指令、可选 SP 或 R2 CPK，不创建平行 Truth。
5. 无冲突时立即进入 Prompt 02。

仅在关键歧义、Truth/ADR 冲突、必须发明新语义、危险操作或外部权限时暂停。输出准入结论、证据路径和精简意图 brief。
