# Prompt 02 — 风险路由与 Truth

所属 runtime 循环：`准入 + 路由`。目标是完成风险 × execution shape 双轴路由、产物选择与 Gate A。

风险轴：R0 不改变 Truth；R1 实现已有 Truth；R2 改变 Truth/ADR/契约/数据/安全/权限/不可逆边界。

形态轴：spike 是可丢弃探索，bounded 是单批次可验收，architectural 需要任务 DAG、所有权或集成。形态只能 `spike -> bounded -> architectural` 升级；spike 不交付可保留变更。

动作：

1. 选择两个轴并记录 `route` 事件、升级条件和 verification profile 下限。
2. 应用产物矩阵：R0 默认零文档；bounded R1 单一 CPK v3；architectural R1 增加 work；R2 使用完整 CPK/Truth Patch，并在 architectural 时增加 work，收口自动 CR。
3. 创建完整 v3 contract，含 Truth ref+SHA-256 digest、ownership batch IDs 与 legacy startup。bounded/spike ownership=none 且 legacy=false；architectural 列唯一 ID，只有真实旧流程启动证据才 legacy=true。
4. R2 已决定时 `gate_a: satisfied`；pending 时只可运行 quiet 的安全只读 `exploration` command event，不得 Truth/实现写入或 close。
5. Gate A 满足后才可应用 Truth Patch；R2 `truth_patch_ref` 指向实际 SoT/Rule。spike 不得 applied/close，必须先升级；非 spike 只在满足机器收口契约时转为 applied。

禁止降级、bounded legacy trio、Truth digest 不匹配、用 CPK/work 替代 Truth，或 R0 默认收口税。输出 CPK/work、Gate、Truth ref/digest、ownership 与 brief。
