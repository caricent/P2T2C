# Prompt 03 — 计划与执行工作批次

所属 runtime 循环：`计划 + 执行`。同一 controller 默认从路由连续进入本循环。

前置：风险/shape 已确定；R1/R2 有合法 CPK v3；R2 `gate_a` 非 pending。

文档强度：

- R0/spike 不创建执行文档。
- bounded R1/R2 把策略、验收和所有权写在 CPK，不创建旧三件套。
- architectural R1/R2 使用单一 `work.md` 记录接口/数据流、任务 DAG、文件所有权、集成顺序、验证和恢复点。

执行纪律：

1. 创建按 work id 隔离的 run ledger；每个事件携带当前 contract digest。Gate A pending 只运行 `exploration` command event；runner 默认 quiet，必要时显式 `--show-output`。
2. `tdd_policy: required` 使用 RED/GREEN；合规豁免用 `tdd_policy: exempt` + `tdd_exemption` 事件；确实不适用才用 `not_applicable`。prompt/skill/脚本优先测消费行为，适用时做 mutation check。
3. architectural 写并行只使用 CPK 中唯一 ownership batch IDs；每个 batch 必须独立 review。bounded 不创建 legacy trio；architectural legacy=true 才保留启动三件套。
4. 只有 controller 派生 Agent；implementer/reviewer 不递归 fan-out。spawn 显式选择快速/标准/最强模型与推理档；使用事件式有界等待。
5. R2、并行或明确要求时使用 workspace isolation；不得覆盖用户改动或强删含内容的 worktree。
6. 持续核对 CPK/work/Truth。发现新语义或升级条件时回到 Prompt 01/02，不静默扩大范围。

完成时报告 diff、ledger、TDD、baseline、ownership、full/governance 与 batch/global/specialist/re_review；不要另造聊天记录。
