# Prompt 04 - Verification and Autonomous Repair

Runtime loop: `Verification + Repair + Drift + Closure`. Continue to Prompt 05 with the same controller.

Goal: Select a diff-appropriate verification set, record actual execution in the machine ledger, and perform at most two repair rounds without changing Truth.

1. Every changed path must match `verification.path_mapping`; no match or command-ID/config-digest mismatch is a hard failure. R2/multi-Agent requires full, governance change adds governance, both complete on one final tree.
2. Run each verification through the recorder so command, exit code, timestamp, tree SHA, and output summary enter the ledger. Example:

```bash
bash .p2t2c/bin/p2t2c_run.sh --work-id CPK-... --event-type verification --verification-profile impacted --command-id p2t2c-check
```

Runner is quiet by default; add `--show-output` only for live diagnosis. Verification does not accept `-- <command>` and executes only a configured command ID in that profile.

3. Before the first repair, use root-cause-debugging: preserve and reproduce failure, trace its source, compare a working pattern, and state a falsifiable hypothesis.
4. Restore CPK implementer both rounds. Each repair records round, hypothesis digest, implementer, failure digest, fix base/head SHA, and fix-diff digest; `review_role: re_review` then links original scope/batch.
5. One unchanged retry is allowed for a clear environment failure. Changed assertions cite Truth, CPK, or acceptance evidence; never weaken a test or delete coverage to pass.

Stop before a third round or new semantics/authority/Truth. Advisory method gaps enter `evidence_warnings` and incomplete completeness, never a complete claim; core mapping/Truth/contract/final-tree failures always block.
