# Plan {NNN}: {Feature Name}

> Compatibility template: v3 permits it only for architectural + `legacy_startup_evidence: true`; bounded/spike cannot create it.

Based on: `spec.md`

## Implementation Strategy

{One sentence describing the overall strategy.}

## Impact

| Module or file | Action | Responsibility |
|---|---|---|
| `{path}` | Add / Modify |  |

## Risks and Handling

| Risk | Handling |
|---|---|
|  |  |

## Verification Strategy

| Check | Command or step | Coverage |
|---|---|---|
| Build / Test / Lint / Typecheck / Governance |  |  |

## Isolation, Collaboration, and Review

- Isolation and clean baseline:
- Parallel ownership boundaries:
- Independent review checkpoint:
