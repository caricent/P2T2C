# Prompt 05 - Drift, Review, and Closure

Runtime loop: `Verification + Repair + Drift + Closure`. Complete drift classification, adaptive review, and machine-evidence projection on the final tree.

1. Compare final code, Truth/ADRs, CPK, and work. Backfill CPK/work Execution Doc Drift automatically.
2. When implementation clearly violates Truth, restore CPK `implementer`, correct it, and re-verify without Gate B. Only accepting implementation and changing Truth records a `gate_b` event, sets `gate_b_status: resolved`, and fills nonempty decision/ref plus the actual `truth_patch_ref`.
3. Bounded uses batch_id=none. Architectural has one batch review per CPK ownership ID, then global and flagged specialist. Fixed findings use re_review linked to original batch/scope.
4. Any nonzero Critical, Important, or Minor finding in a required review blocks CLOSE. The original implementer repairs, scoped re-review checks finding + fix diff, and final-tree verification remains fresh.
5. Validate ledger and project the receipt with close tooling:

```bash
bash .p2t2c/bin/p2t2c_close.sh --work-id CPK-... --verification-profile full
```

6. Receipt projects Gate A/Truth/ownership/legacy, `methodology_enforcement`, `evidence_completeness`, `evidence_warnings`, mapping/matched paths, baseline/risk ref. Warnings never masquerade as complete; close rolls back on failure.

Do not claim `CLOSE` without final-tree required verification/review, with blocking findings, or when evidence digest mismatches.
