# Tasks {NNN}: {功能名称}

> 兼容模板：v3 仅允许 architectural + `legacy_startup_evidence: true`；当前 ownership IDs 仍以 CPK/work 为准。

Based on: `spec.md` + `plan.md`

## 工作批次

一个批次可以包含多个服务同一目标、可整体验收的相关 Task。

- [ ] Task 1：{交付物}
- [ ] Task 2：{交付物}
- [ ] Task 3：{交付物}

## 批次级验收

| 命令或步骤 | 预期结果 |
|---|---|
| `{command}` |  |

## 批次方法检查点

- RED 证据或豁免：
- 发生修复时必须记录根因。
- 是否需要独立审查：是 / 否

## 批次边界

- 不包含：
- 发现新的语义边界、Truth 冲突或高风险事项时返回意图准入阶段。
