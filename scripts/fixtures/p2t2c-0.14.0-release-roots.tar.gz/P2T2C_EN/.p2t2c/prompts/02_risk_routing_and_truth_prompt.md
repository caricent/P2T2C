# Prompt 02 - Risk Routing and Truth

Runtime loop: `Admission + Routing`. Complete dual-axis risk x execution-shape routing, artifact selection, and Gate A.

Risk axis: R0 does not change Truth; R1 implements existing Truth; R2 changes Truth/ADR/contract/data/security/permission/irreversible boundaries.

Shape axis: spike is disposable exploration, bounded is one-batch acceptance, architectural needs a task DAG, ownership, or integration. Shape upgrades only `spike -> bounded -> architectural`; a spike ships no retained change.

Actions:

1. Select both axes and record a `route` event, upgrade conditions, and minimum verification profile.
2. Apply the matrix: R0 has no doc by default; bounded R1 one CPK v3; architectural R1 adds work; R2 uses complete CPK/Truth Patch and adds work when architectural, with an automatic CR at closure.
3. Create the complete v3 contract including Truth ref+SHA-256 digest, ownership batch IDs, and legacy startup. Bounded/spike uses ownership none and legacy false; architectural lists unique IDs and uses legacy true only for real old-workflow startup evidence.
4. R2 decided semantics uses `gate_a: satisfied`. Pending permits only quiet, safe, read-only `exploration` command events, with no Truth/implementation write or close.
5. Apply a Truth Patch only after Gate A and point R2 `truth_patch_ref` to the actual SoT/rule. Spike cannot become applied or close and must upgrade first; non-spike becomes applied only when the machine closure contract is satisfied.

Do not downgrade, allow bounded legacy trio, accept Truth-digest mismatch, replace Truth with CPK/work, or impose R0 closure tax. Output CPK/work, gate, Truth ref/digest, ownership, and brief.
